-- View data in Customer table
SELECT * FROM Customer;