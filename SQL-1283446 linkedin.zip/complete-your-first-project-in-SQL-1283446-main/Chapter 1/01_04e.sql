-- Sort Orders table
SELECT * FROM Orders
ORDER BY CreationDate DESC;