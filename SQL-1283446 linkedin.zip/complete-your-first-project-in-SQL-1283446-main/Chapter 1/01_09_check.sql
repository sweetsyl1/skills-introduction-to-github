SELECT * FROM Customer
WHERE CustomerID= 1100;