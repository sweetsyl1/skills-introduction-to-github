-- View data in Product table
SELECT * FROM Product;