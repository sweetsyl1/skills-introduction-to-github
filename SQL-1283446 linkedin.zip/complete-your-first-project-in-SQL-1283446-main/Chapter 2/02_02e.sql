-- Determine which items are discontinued
SELECT *
FROM Product
WHERE Status = "DISCONTINUED";